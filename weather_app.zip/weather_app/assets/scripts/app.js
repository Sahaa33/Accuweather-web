//<div class="display-4 my-4">
  //<span>${weather.Temperature.Metric.Value}</span>
  //<span>&deg;C</span>
//</div>
const cityForm = document.querySelector("form");
const details1 = document.querySelector(".details1");
const details2 = document.querySelector(".details2");
const icon1 = document.querySelector(".icon1 img");
const icon2 = document.querySelector(".icon2 img");
const min = document.querySelector(".min");
const max = document.querySelector(".max");

const updateUI = async(data) => {
  const cityDets = data.cityDets;
  const weather = data.weather;

  details1.innerHTML = `
  <h5 class="my-3">${cityDets.EnglishName}</h5>
  <div class="my-3">${weather.DailyForecasts[0].Day.IconPhrase}</div>
  `
  details2.innerHTML = `
  <h5 class="my-3">${cityDets.EnglishName}</h5>
  <div class="my-3">${weather.DailyForecasts[0].Night.IconPhrase}</div>
  `
  function toCelsius(f) {
  let num = (5/9) * (f-32);
  return num.toFixed(1);
}
  min.innerHTML = "Minimum Temperature is: " + toCelsius(weather.DailyForecasts[0].Temperature.Minimum.Value) + "&deg;C";
  max.innerHTML = "Maximum Temperature is: " + toCelsius(weather.DailyForecasts[0].Temperature.Maximum.Value) + "&deg;C";
  //update the night/day and icon images
  const iconSrc1 = `assets/img/icons/${weather.DailyForecasts[0].Day.Icon}.svg`;
  icon1.setAttribute("src", iconSrc1);
  const iconSrc2 = `assets/img/icons/${weather.DailyForecasts[0].Night.Icon}.svg`;
  icon2.setAttribute("src", iconSrc2);


};




const updateCity = async(city) => {
  const cityDets = await getCity(city);
  const weather = await getWeather(cityDets.Key);

  return {
    cityDets: cityDets,
    weather: weather
  };
};
cityForm.addEventListener("submit", e => {
  e.preventDefault();
  const city = cityForm.city.value.trim();
  cityForm.reset();

  updateCity(city)
  .then(data => updateUI(data))
  .catch(err => console.log (err));


});
