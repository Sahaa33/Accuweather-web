<?php
require 'database/config.php';
require 'includes/login.php';
require 'includes/signup-form.php';
  if(isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'] ;
    $userdetails = mysqli_query($con, "SELECT * FROM users WHERE user_id='$user_id'");
    $row = mysqli_fetch_array($userdetails);
    $fname = $row["fname"];
    $lname = $row["lname"];

}
?>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="stylesheet" href="assets/css/styles.css">
  <title>Weather app</title>
</head>
<body>

    <div class="container my-5 mx-auto">

        <h1 class="text-muted text-center my-4"></h1>

        <form class="change-location my-4 text-center text-muted">
          <p><?php echo "Hello " .$fname . " " . $lname;?><label for="city">Enter a location for weather information</label></p>
          <input type="text" name="city" class="form-control p-4">
        </form>
      </div>
        <div class="main">
          <div class="card shadow-lg rounded">
            <img src="assets\img\day.svg" class="time card-img-top">
            <div class="icon1 bg-light mx-auto text-center">
              <img src="" alt="">
            </div>
            <div class="text-muted text-uppercase text-center details1">
              <div class="my-3">Weather condition</div>
              <div class="display-4 my-4">
                <span>temp</span>
                <span>&deg;C</span>
              </div>
            </div>
          </div>
          <div class="temp">
            <p class="min">Min temp is: </p>
            <p class="max">Max temp is: </p>
            <a href="logout.php">Logout</a>
          </div>
          <div class="card shadow-lg rounded">
            <img src="assets\img\night.svg" class="time card-img-top">
            <div class="icon2 bg-light mx-auto text-center">
              <img src="" alt="">
            </div>
            <div class="text-muted text-uppercase text-center details2">
              <div class="my-3">Weather condition</div>
              <div class="display-4 my-4">
                <span>temp</span>
                <span>&deg;C</span>
              </div>
            </div>
          </div>
        </div>

  <script src="assets/scripts/forecast.js"></script>
  <script src="assets/scripts/app.js"></script>
</body>
</html>
